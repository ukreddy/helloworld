function Write-Log {
    param($Message, $Level = "INFO")

    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $formatted = "[$time] [$Level] $Message"

    if ($Level -eq "ERROR") {
        Write-Host $formatted -ForegroundColor Red
        return
    }

    if ($Level -eq "WARN") {
        Write-Host $formatted -ForegroundColor Yellow
        return
    }

    Write-Host $formatted
}

function Invoke-Retry {
    param(
        [scriptblock]$ScriptBlock,
        [int]$MaxRetries = 3,
        [int]$DelaySeconds = 3
    )

    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            Write-Log "Attempt $i of $MaxRetries"
            return & $ScriptBlock
        }
        catch {
            Write-Log $_.Exception.Message "ERROR"

            if ($i -eq $MaxRetries) { throw }

            Start-Sleep -Seconds ($DelaySeconds * $i)
        }
    }
}

function Connect-SPSite {

    param([string]$SiteUrl)

    Write-Log "Connecting to SharePoint Site"

    $securePassword = ConvertTo-SecureString `
        $env:PNP_CERT_PASSWORD `
        -AsPlainText `
        -Force

    Connect-PnPOnline `
        -Url $SiteUrl `
        -Tenant $env:PNP_TENANT_ID `
        -ClientId $env:PNP_CLIENT_ID `
        -CertificateBase64Encoded $env:PNP_CERT_BASE64 `
        -CertificatePassword $securePassword

    Write-Log "Connected to $SiteUrl"
}

function Connect-GraphApi {

    Write-Log "Connecting Graph API"

    $token = Get-PnPAccessToken -ResourceTypeName Graph

    if (-not $token) {
        throw "Unable to obtain Graph token"
    }

    $script:GraphHeaders = @{
        Authorization  = "Bearer $token"
        "Content-Type" = "application/json"
    }

    Write-Log "Graph ready"
}

function New-LibraryIfMissing {

    param([string]$LibraryName)

    $existing = Get-PnPList -Identity $LibraryName -ErrorAction SilentlyContinue

    if ($existing) {
        Write-Log "Library exists: $LibraryName"
        return
    }

    Write-Log "Creating library: $LibraryName"

    New-PnPList `
        -Title $LibraryName `
        -Template DocumentLibrary `
        -OnQuickLaunch:$true

    Write-Log "Library created: $LibraryName"
}

function New-EntraGroupIfMissing {

    param([string]$GroupName)

    Write-Log "Checking Entra group: $GroupName"

    $filter = [System.Uri]::EscapeDataString("displayName eq '$GroupName'")

    $existing = Invoke-RestMethod `
        -Method GET `
        -Uri "https://graph.microsoft.com/v1.0/groups?`$filter=$filter" `
        -Headers $script:GraphHeaders

    if ($existing -and $existing.value -and $existing.value.Count -gt 0) {
        Write-Log "Group exists"
        return $existing.value[0].id
    }

    Write-Log "Creating Entra group"

    $body = @{
        displayName     = $GroupName
        mailEnabled     = $false
        mailNickname    = ($GroupName -replace '[^a-zA-Z0-9]', '').ToLower()
        securityEnabled = $true
    } | ConvertTo-Json

    $group = Invoke-RestMethod `
        -Method POST `
        -Uri "https://graph.microsoft.com/v1.0/groups" `
        -Headers $script:GraphHeaders `
        -Body $body

    Write-Log "Created group: $($group.id)"

    return $group.id
}

function Get-EntraGroupLoginName {

    param([string]$GroupId)

    if (-not $GroupId) {
        throw "GroupId is required"
    }

    # SharePoint claim format for Entra security groups
    return "c:0t.c|tenant|$GroupId"
}

function Break-LibraryInheritance {

    param([string]$LibraryName)

    Write-Log "Breaking inheritance: $LibraryName"

    Set-PnPList `
        -Identity $LibraryName `
        -BreakRoleInheritance `
        -CopyRoleAssignments:$false `
        -ClearSubscopes:$true

    Write-Log "Inheritance broken"
}

# ---------------- FIXED GROUP RESOLUTION ----------------

function Resolve-SPGroup {

    param(
        [string]$GroupName,
        [int]$TimeoutSeconds = 60
    )

    Write-Log "Resolving SP group: $GroupName"

    for ($i = 0; $i -lt $TimeoutSeconds / 5; $i++) {

        $group = Get-PnPGroup -Identity $GroupName -ErrorAction SilentlyContinue

        if ($group) {
            return $group
        }

        Start-Sleep 5
    }

    throw "SharePoint group not found: $GroupName"
}

function Ensure-GroupInSite {

    param([string]$GroupName)

    $existing = Get-PnPGroup -Identity $GroupName -ErrorAction SilentlyContinue

    if ($existing) {
        Write-Log "$GroupName already in site"
        return $existing
    }

    Write-Log "Creating SharePoint group: $GroupName"

    New-PnPGroup -Title $GroupName | Out-Null

    return Resolve-SPGroup -GroupName $GroupName
}

function Add-EntraGroupToSPGroup {

    param(
        [string]$SPGroupName,
        [string]$EntraGroupId,
        [int]$TimeoutSeconds = 90
    )

    $loginName = Get-EntraGroupLoginName -GroupId $EntraGroupId
    $attempts = [Math]::Ceiling($TimeoutSeconds / 5)

    for ($i = 1; $i -le $attempts; $i++) {
        try {
            Add-PnPGroupMember -Group $SPGroupName -LoginName $loginName
            Write-Log "Added Entra group $EntraGroupId to $SPGroupName"
            return
        }
        catch {
            $message = $_.Exception.Message

            if ($message -match "already" -or $message -match "exists") {
                Write-Log "Entra group already in $SPGroupName"
                return
            }

            if ($i -eq $attempts) {
                throw "Unable to add Entra group $EntraGroupId to ${SPGroupName}: $message"
            }

            Start-Sleep -Seconds 5
        }
    }
}

# ---------------- FIXED PERMISSION ----------------

function Grant-LibraryPermission {

    param(
        [string]$LibraryName,
        [string]$GroupName,
        [string]$Role
    )

    Write-Log "Assigning $Role to $GroupName on $LibraryName"

    Set-PnPListPermission `
        -Identity $LibraryName `
        -Group $GroupName `
        -AddRole $Role

    Write-Log "Permission assigned"
}

function Ensure-LibraryInQuickLaunch {

    param([string]$LibraryName)

    Write-Log "Ensuring Quick Launch link for library: $LibraryName"

    $list = Get-PnPList -Identity $LibraryName -ErrorAction SilentlyContinue
    if (-not $list) {
        throw "Library not found: $LibraryName"
    }

    $targetUrl = [string]$list.DefaultViewUrl
    if ([string]::IsNullOrWhiteSpace($targetUrl)) {
        throw "Unable to resolve default view URL for library: $LibraryName"
    }

    $nodes = @(Get-PnPNavigationNode -Location QuickLaunch -Tree -ErrorAction SilentlyContinue)

    function Find-NavigationNode {
        param(
            [object[]]$Items,
            [string]$Title,
            [string]$Url
        )

        foreach ($item in @($Items)) {
            if (-not $item) {
                continue
            }

            $itemTitle = [string]$item.Title
            $itemUrl = [string]$item.Url

            if (($itemTitle -eq $Title) -or ($itemUrl -eq $Url)) {
                return $true
            }

            if ($item.Children -and (Find-NavigationNode -Items @($item.Children) -Title $Title -Url $Url)) {
                return $true
            }
        }

        return $false
    }

    if (-not (Find-NavigationNode -Items $nodes -Title $LibraryName -Url $targetUrl)) {
        Add-PnPNavigationNode `
            -Location QuickLaunch `
            -Title $LibraryName `
            -Url $targetUrl | Out-Null
    }

    Write-Log "Quick Launch enabled: $LibraryName"
}

function Add-ExternalUserToSPGroup {

    param(
        [string]$SPGroupName,
        [string]$UserEmail
    )

    if ([string]::IsNullOrWhiteSpace($SPGroupName)) {
        throw "SPGroupName is required"
    }

    if ([string]::IsNullOrWhiteSpace($UserEmail)) {
        throw "UserEmail is required"
    }

    $normalizedEmail = $UserEmail.Trim().ToLower()

    try {
        Add-PnPGroupMember -Group $SPGroupName -EmailAddress $normalizedEmail -ErrorAction Stop
        Write-Log "Added external user $normalizedEmail to $SPGroupName"
        return "added"
    }
    catch {
        $message = $_.Exception.Message

        if ($message -match "already" -or $message -match "exists" -or $message -match "member") {
            Write-Log "External user already in ${SPGroupName}: $normalizedEmail"
            return "already_exists"
        }

        throw "Unable to add external user $normalizedEmail to ${SPGroupName}: $message"
    }
}

function Provision-HomePage {

    param(
        [string]$SiteUrl,
        [string]$JobNumber,
        [datetime]$CreatedDate = (Get-Date)
    )

    if ([string]::IsNullOrWhiteSpace($SiteUrl)) {
        throw "SiteUrl is required"
    }

    if ([string]::IsNullOrWhiteSpace($JobNumber)) {
        throw "JobNumber is required"
    }

    Write-Log "Provisioning home page for site: $SiteUrl"

    try {
        $pageName = "Home"

        $page = Get-PnPPage -Identity $pageName -ErrorAction SilentlyContinue
        if (-not $page) {
            Add-PnPPage -Name $pageName -LayoutType Home -Title $pageName -ErrorAction Stop | Out-Null
            Write-Log "Created home page: $pageName"
        }
        else {
            Write-Log "Updating existing home page: $pageName"
        }

        $page = Get-PnPPage -Identity $pageName -ErrorAction Stop

        foreach ($control in @($page.Controls)) {
            if ($null -ne $control.InstanceId) {
                Remove-PnPPageComponent -Page $pageName -InstanceId $control.InstanceId -Force -ErrorAction Stop
            }
        }
        Write-Log "Removed existing page components"

        $sectionCount = @($page.Sections).Count
        while ($sectionCount -lt 2) {
            Add-PnPPageSection -Page $pageName -SectionTemplate OneColumn -ErrorAction Stop | Out-Null
            $sectionCount++
        }

        Add-PnPPageTextPart `
            -Page $pageName `
            -Text '<h2>Recent activity</h2><p>Recently modified documents across all libraries.</p>' `
            -Section 1 `
            -Column 1 `
            -Order 1 `
            -ErrorAction Stop | Out-Null

        Add-PnPPageWebPart `
            -Page $pageName `
            -DefaultWebPartType ContentRollup `
            -Section 1 `
            -Column 1 `
            -Order 2 `
            -ErrorAction Stop | Out-Null
        Write-Log "Added highlighted content webpart to recent activity section"

        $createdDateFormatted = $CreatedDate.ToString("MMMM d, yyyy")
        $siteInfoContent = @"
<h2>Site information</h2>
<p><strong>Job Number:</strong> $JobNumber</p>
<p><strong>Created Date:</strong> $createdDateFormatted</p>
<p><strong>Site URL:</strong> $SiteUrl</p>
<p>This site is dedicated to managing resources and documents for Job $JobNumber.</p>
"@

        Add-PnPPageTextPart `
            -Page $pageName `
            -Text $siteInfoContent `
            -Section 2 `
            -Column 1 `
            -Order 1 `
            -ErrorAction Stop | Out-Null
        Write-Log "Added site information text webpart"

        Set-PnPPage -Identity $pageName -Publish -ErrorAction Stop | Out-Null
        Write-Log "Published home page"
        Write-Log "Home page provisioned successfully"
    }
    catch {
        $message = $_.Exception.Message
        Write-Log "Failed to provision home page: $message" "ERROR"
        throw "Home page provisioning failed: $message"
    }
}