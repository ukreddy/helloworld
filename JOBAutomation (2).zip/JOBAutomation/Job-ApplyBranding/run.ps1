param($Request, $TriggerMetadata)

. "$PSScriptRoot/../Shared/helpers.ps1"

$tenant =$env:PNP_TENANT_NAME

function Get-RequestBodyObject {
    param($HttpRequest)

    if (-not $HttpRequest.Body) {
        return $null
    }

    if ($HttpRequest.Body -is [string]) {
        if ([string]::IsNullOrWhiteSpace($HttpRequest.Body)) {
            return $null
        }

        try {
            return $HttpRequest.Body | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "Request body must be valid JSON."
        }
    }

    return $HttpRequest.Body
}

function Convert-ToBoolean {
    param($Value)

    if ($null -eq $Value) {
        return $null
    }

    if ($Value -is [bool]) {
        return $Value
    }

    $stringValue = [string]$Value

    if ([string]::IsNullOrWhiteSpace($stringValue)) {
        return $null
    }

    switch ($stringValue.Trim().ToLower()) {
        "true" { return $true }
        "1" { return $true }
        "yes" { return $true }
        "y" { return $true }
        "false" { return $false }
        "0" { return $false }
        "no" { return $false }
        "n" { return $false }
        default {
            throw "Unable to convert '$stringValue' to boolean. Use true or false."
        }
    }
}

try {
    Write-Log "Apply Branding Started"

    $bodyObject = Get-RequestBodyObject -HttpRequest $Request

    $jobNumber = $Request.Query.jobNumber
    if (-not $jobNumber -and $bodyObject) {
        $jobNumber = $bodyObject.jobNumber
    }

    $siteUrl = $Request.Query.siteUrl
    if (-not $siteUrl -and $bodyObject) {
        $siteUrl = $bodyObject.siteUrl
    }

    if (-not $siteUrl -and $jobNumber) {
        $siteUrl = "https://$tenant.sharepoint.com/sites/PC-JOB-$jobNumber"
    }

    if (-not $siteUrl) {
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = 400
            Body       = (@{
                status = "failed"
                error  = "Provide either siteUrl or jobNumber in query string or request body"
            } | ConvertTo-Json)
        })
        return
    }

    $siteTitle = $null
    if ($bodyObject -and $bodyObject.siteTitle) {
        $siteTitle = [string]$bodyObject.siteTitle
    }
    elseif ($jobNumber) {
        $siteTitle = "PC-JOB-$jobNumber"
    }

    $siteDescription = $Request.Query.siteDescription
    if (-not $siteDescription -and $bodyObject -and $bodyObject.siteDescription) {
        $siteDescription = [string]$bodyObject.siteDescription
    }

    $customLogoUrl = $Request.Query.customLogoUrl
    if (-not $customLogoUrl -and $bodyObject -and $bodyObject.customLogoUrl) {
        $customLogoUrl = [string]$bodyObject.customLogoUrl
    }
    if (-not $customLogoUrl -and $env:CUSTOMLOGO_URL) {
        $customLogoUrl = [string]$env:CUSTOMLOGO_URL
    }
    if (-not $customLogoUrl -and $env:CUSTOM_LOGO_URL) {
        $customLogoUrl = [string]$env:CUSTOM_LOGO_URL
    }
    if (-not $customLogoUrl -and $env:JOB_BRANDING_CUSTOM_LOGO_URL) {
        $customLogoUrl = [string]$env:JOB_BRANDING_CUSTOM_LOGO_URL
    }

    $logoUrl = $Request.Query.logoUrl
    if (-not $logoUrl -and $bodyObject -and $bodyObject.logoUrl) {
        $logoUrl = [string]$bodyObject.logoUrl
    }
    if (-not $logoUrl -and $env:JOB_BRANDING_LOGO_URL) {
        $logoUrl = [string]$env:JOB_BRANDING_LOGO_URL
    }
    if (-not [string]::IsNullOrWhiteSpace($customLogoUrl)) {
        $logoUrl = $customLogoUrl
    }

    $themeName = $Request.Query.themeName
    if (-not $themeName -and $bodyObject -and $bodyObject.themeName) {
        $themeName = [string]$bodyObject.themeName
    }
    if (-not $themeName -and $env:JOB_BRANDING_THEME_NAME) {
        $themeName = [string]$env:JOB_BRANDING_THEME_NAME
    }

    $enableQuickLaunch = $null
    if ($Request.Query.enableQuickLaunch) {
        $enableQuickLaunch = Convert-ToBoolean -Value $Request.Query.enableQuickLaunch
    }
    elseif ($bodyObject -and $null -ne $bodyObject.enableQuickLaunch) {
        $enableQuickLaunch = Convert-ToBoolean -Value $bodyObject.enableQuickLaunch
    }

    $refreshHomePage = $null
    if ($Request.Query.refreshHomePage) {
        $refreshHomePage = Convert-ToBoolean -Value $Request.Query.refreshHomePage
    }
    elseif ($bodyObject -and $null -ne $bodyObject.refreshHomePage) {
        $refreshHomePage = Convert-ToBoolean -Value $bodyObject.refreshHomePage
    }

    if (-not $jobNumber -and $siteUrl -match '/sites/PC-JOB-(?<jobNumber>[^/]+)$') {
        $jobNumber = $Matches.jobNumber
    }

    Invoke-Retry -ScriptBlock {
        Connect-SPSite -SiteUrl $siteUrl
    }

    $actions = @()
    $homePageCreatedDate = $null

    if (-not [string]::IsNullOrWhiteSpace($siteTitle)) {
        Invoke-Retry -ScriptBlock {
            Set-PnPWeb -Title $siteTitle
        }

        $actions += "title"
        Write-Log "Applied site title: $siteTitle"
    }

    if (-not [string]::IsNullOrWhiteSpace($siteDescription)) {
        Invoke-Retry -ScriptBlock {
            Set-PnPWeb -Description $siteDescription
        }

        $actions += "description"
        Write-Log "Applied site description"
    }

    if (-not [string]::IsNullOrWhiteSpace($logoUrl)) {
        Invoke-Retry -ScriptBlock {
            Set-PnPWeb -SiteLogoUrl $logoUrl
        }

        $actions += "logo"
        Write-Log "Applied site logo"
    }

    if (-not [string]::IsNullOrWhiteSpace($themeName)) {
        if (Get-Command Set-PnPWebTheme -ErrorAction SilentlyContinue) {
            Invoke-Retry -ScriptBlock {
                Set-PnPWebTheme -Theme $themeName
            }

            $actions += "theme"
            Write-Log "Applied theme: $themeName"
        }
        else {
            Write-Log "Set-PnPWebTheme command is unavailable in the installed PnP.PowerShell version" "WARN"
        }
    }

    if ($null -ne $enableQuickLaunch) {
        Invoke-Retry -ScriptBlock {
            Set-PnPWeb -QuickLaunchEnabled:$enableQuickLaunch
        }

        $actions += "quickLaunch"
        Write-Log "Updated Quick Launch setting: $enableQuickLaunch"
    }

    if ($refreshHomePage -eq $true) {
        if ([string]::IsNullOrWhiteSpace($jobNumber)) {
            throw "jobNumber is required to refresh the Home page. Provide jobNumber directly or use a siteUrl matching /sites/PC-JOB-{jobNumber}."
        }

        $homePageCreatedDate = Invoke-Retry -ScriptBlock {
            $web = Get-PnPWeb -Includes Created -ErrorAction Stop
            $createdDate = $web.Created
            if ($null -eq $createdDate) {
                $createdDate = Get-Date
            }

            Provision-HomePage `
                -SiteUrl $siteUrl `
                -JobNumber $jobNumber `
                -CreatedDate $createdDate | Out-Null

            return $createdDate
        }

        $actions += "homePage"
        Write-Log "Refreshed Home page"
    }

    if ($actions.Count -eq 0) {
        Write-Log "No branding settings supplied. Nothing to update." "WARN"
    }

    $homePageCreatedDateValue = $null
    if ($null -ne $homePageCreatedDate) {
        if ($homePageCreatedDate -is [datetime]) {
            $homePageCreatedDateValue = $homePageCreatedDate.ToString("o")
        }
        else {
            try {
                $homePageCreatedDateValue = ([datetime]$homePageCreatedDate).ToString("o")
            }
            catch {
                $homePageCreatedDateValue = [string]$homePageCreatedDate
            }
        }
    }

    $response = @{
        status      = "success"
        siteUrl     = $siteUrl
        siteTitle   = $siteTitle
        siteDescription = $siteDescription
        customLogoUrl = $customLogoUrl
        logoUrl     = $logoUrl
        themeName   = $themeName
        refreshHomePage = $refreshHomePage
        homePageCreatedDate = $homePageCreatedDateValue
        actions     = $actions
        message     = if ($actions.Count -eq 0) { "No branding values provided." } else { "Branding applied successfully." }
    }

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = 200
        Body       = ($response | ConvertTo-Json -Depth 5)
    })
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Log "Apply Branding failed: $errorMessage" "ERROR"

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = 500
        Body       = (@{
            status = "failed"
            error  = $errorMessage
        } | ConvertTo-Json)
    })
}
