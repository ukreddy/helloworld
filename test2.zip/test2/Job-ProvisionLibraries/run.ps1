param($Request, $TriggerMetadata)

$tenant = "n8gv"

function Convert-ToBoolean {
    param($Value)

    if ($null -eq $Value) {
        return $null
    }

    if ($Value -is [bool]) {
        return $Value
    }

    $stringValue = [string]$Value
    if ([string]::IsNullOrWhiteSpace($stringValue)) {
        return $null
    }

    switch ($stringValue.Trim().ToLower()) {
        "true" { return $true }
        "1" { return $true }
        "yes" { return $true }
        "y" { return $true }
        "false" { return $false }
        "0" { return $false }
        "no" { return $false }
        "n" { return $false }
        default { throw "Unable to convert '$stringValue' to boolean. Use true or false." }
    }
}

function Test-IsValidEmailAddress {
    param([string]$Email)

    if ([string]::IsNullOrWhiteSpace($Email)) {
        return $false
    }

    return $Email.Trim() -match '^[^@\s]+@[^@\s]+\.[^@\s]+$'
}

function Get-RequestBodyObject {
    param($HttpRequest)

    if (-not $HttpRequest.Body) {
        return $null
    }

    if ($HttpRequest.Body -is [string]) {
        if ([string]::IsNullOrWhiteSpace($HttpRequest.Body)) {
            return $null
        }

        try {
            return $HttpRequest.Body | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "Request body must be valid JSON."
        }
    }

    return $HttpRequest.Body
}

try {
    $helpersPath = "$PSScriptRoot/../Shared/helpers.ps1"
    if (-not (Test-Path $helpersPath)) {
        throw "Helpers file not found at $helpersPath"
    }

    . $helpersPath
    Write-Log "Provision Libraries Started"

    $bodyObject = Get-RequestBodyObject -HttpRequest $Request

    $jobNumber = $Request.Query.jobNumber
    if (-not $jobNumber -and $bodyObject) {
        $jobNumber = $bodyObject.jobNumber
    }

    if (-not $jobNumber) {
        Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
            StatusCode = 400
            Body       = (@{
                status = "failed"
                error  = "jobNumber is required in query string or request body"
            } | ConvertTo-Json)
        })
        return
    }

    $siteUrl = "https://$tenant.sharepoint.com/sites/PC-JOB-$jobNumber"
    $ownersGroup = "PC-JOB-$jobNumber-Owner"
    $ownersSPGroup = "PC-JOB-$jobNumber-OWNER-SP"

function Get-LibraryConfiguration {

    function Convert-LibrariesJson {
        param([string]$RawJson)

        if ([string]::IsNullOrWhiteSpace($RawJson)) {
            return $null
        }

        $trimmed = $RawJson.Trim()
        $candidates = @($trimmed)

        # Azure app settings are sometimes saved with outer quotes around the full JSON payload.
        if ($trimmed.Length -ge 2) {
            if (($trimmed.StartsWith('"') -and $trimmed.EndsWith('"')) -or
                ($trimmed.StartsWith("'") -and $trimmed.EndsWith("'"))) {
                $candidates += $trimmed.Substring(1, $trimmed.Length - 2)
            }
        }

        foreach ($candidate in $candidates) {
            if ([string]::IsNullOrWhiteSpace($candidate)) {
                continue
            }

            try {
                $parsed = $candidate | ConvertFrom-Json -ErrorAction Stop

                # Handle double-encoded JSON where first parse returns the JSON text.
                if ($parsed -is [string] -and -not [string]::IsNullOrWhiteSpace($parsed)) {
                    $parsed = $parsed | ConvertFrom-Json -ErrorAction Stop
                }

                return $parsed
            }
            catch {
                continue
            }
        }

        throw 'JOB_LIBRARIES_JSON must be valid JSON. Example: [{"Name":"HR Materials","ShortName":"HR"}]'
    }

    $defaultLibraries = @(
        @{
            Name = "HR Materials"
            ShortName = "HR"
            Type = "internal"
            ExternalUsers = @()
            ExternalRole = "Edit"
        },
        @{
            Name = "Training"
            ShortName = "TRAIN"
            Type = "internal"
            ExternalUsers = @()
            ExternalRole = "Edit"
        },
        @{
            Name = "Client Documents"
            ShortName = "CLIENT"
            Type = "internal"
            ExternalUsers = @()
            ExternalRole = "Edit"
        }
    )

    $configuredLibraries = $null

    if (-not $configuredLibraries -and $env:JOB_LIBRARIES_JSON) {
        $configuredLibraries = Convert-LibrariesJson -RawJson $env:JOB_LIBRARIES_JSON
        Write-Log "Using libraries from JOB_LIBRARIES_JSON"
    }

    if (-not $configuredLibraries) {
        Write-Log "Using default libraries"
        return $defaultLibraries
    }

    $normalized = @()

    foreach ($library in @($configuredLibraries)) {
        $name = [string]$library.Name
        $shortName = [string]$library.ShortName
        $type = [string]$library.Type
        $externalRole = [string]$library.ExternalRole
        $externalUsersRaw = @()

        if ($null -ne $library.ExternalUsers) {
            $externalUsersRaw = @($library.ExternalUsers)
        }

        if ([string]::IsNullOrWhiteSpace($name) -or [string]::IsNullOrWhiteSpace($shortName)) {
            throw "Each library must include non-empty Name and ShortName."
        }

        if ([string]::IsNullOrWhiteSpace($type)) {
            $type = "internal"
        }

        $type = $type.Trim().ToLower()
        if ($type -ne "internal" -and $type -ne "external") {
            throw "Library '$name' has invalid Type '$type'. Use 'internal' or 'external'."
        }

        if ([string]::IsNullOrWhiteSpace($externalRole)) {
            $externalRole = "Edit"
        }

        $externalRole = $externalRole.Trim()
        if ($externalRole -ne "Read" -and $externalRole -ne "Edit") {
            throw "Library '$name' has invalid ExternalRole '$externalRole'. Use 'Read' or 'Edit'."
        }

        $externalUsers = @()
        $seenExternalUsers = @{}

        foreach ($rawUser in @($externalUsersRaw)) {
            $email = [string]$rawUser
            if ([string]::IsNullOrWhiteSpace($email)) {
                continue
            }

            $email = $email.Trim().ToLower()

            if (-not (Test-IsValidEmailAddress -Email $email)) {
                throw "Library '$name' has invalid external email '$email'."
            }

            if (-not $seenExternalUsers.ContainsKey($email)) {
                $seenExternalUsers[$email] = $true
                $externalUsers += $email
            }
        }

        if ($type -eq "internal" -and $externalUsers.Count -gt 0) {
            throw "Library '$name' is internal and cannot include ExternalUsers. Set Type to 'external' first."
        }

        $normalized += @{
            Name = $name.Trim()
            ShortName = $shortName.Trim().ToUpper()
            Type = $type
            ExternalUsers = $externalUsers
            ExternalRole = $externalRole
        }
    }

    return $normalized
}

$libraries = Get-LibraryConfiguration
Write-Log "Libraries configured: $($libraries.Count)"

$enableExternalSharing = $false
if (-not [string]::IsNullOrWhiteSpace([string]$env:ENABLE_LIBRARY_EXTERNAL_SHARING)) {
    $enableExternalSharing = Convert-ToBoolean -Value $env:ENABLE_LIBRARY_EXTERNAL_SHARING
}

Write-Log "External library sharing enabled: $enableExternalSharing"

# Connect SharePoint
Invoke-Retry -ScriptBlock {
    Connect-SPSite -SiteUrl $siteUrl
}

# Connect Graph
Invoke-Retry -ScriptBlock {
    Connect-GraphApi
}

# Create job-level Owners Entra group once
$ownersGroupId = Invoke-Retry -ScriptBlock {
    New-EntraGroupIfMissing -GroupName $ownersGroup
}

Write-Log "Owners Group Id : $ownersGroupId"

# Ensure one job-level SharePoint Owners group and add Owners Entra group once
Invoke-Retry -ScriptBlock {
    Ensure-GroupInSite -GroupName $ownersSPGroup
}

Invoke-Retry -ScriptBlock {
    Add-EntraGroupToSPGroup `
        -SPGroupName $ownersSPGroup `
        -EntraGroupId $ownersGroupId
}

$result = @()
$failedCount = 0

foreach ($library in $libraries) {

    $libraryName = $library.Name
    $shortName   = $library.ShortName
    $libraryType = $library.Type
    $externalUsers = @($library.ExternalUsers)
    $externalRole = $library.ExternalRole

    Write-Log "Processing $libraryName (Type: $libraryType)"

    $readGroup = "PC-JOB-$jobNumber-$shortName-R"
    $editGroup = "PC-JOB-$jobNumber-$shortName-RW"
    $readSPGroup = "PC-JOB-$jobNumber-$shortName-READ-SP"
    $editSPGroup = "PC-JOB-$jobNumber-$shortName-EDIT-SP"

    $externalUsersAdded = @()
    $externalUsersSkipped = @()
    $externalTargetSPGroup = $editSPGroup

    try {

        # Create Library
        Invoke-Retry -ScriptBlock {
            New-LibraryIfMissing -LibraryName $libraryName
        }

        Invoke-Retry -ScriptBlock {
            Ensure-LibraryInQuickLaunch -LibraryName $libraryName
        }

        # Create Entra Groups
        $readGroupId = Invoke-Retry -ScriptBlock {
            New-EntraGroupIfMissing -GroupName $readGroup
        }

        $editGroupId = Invoke-Retry -ScriptBlock {
            New-EntraGroupIfMissing -GroupName $editGroup
        }

        Write-Log "Read Group Id : $readGroupId"
        Write-Log "Edit Group Id : $editGroupId"

        # Break inheritance
        Invoke-Retry -ScriptBlock {
            Break-LibraryInheritance -LibraryName $libraryName
        }

        # Ensure SharePoint permission groups in site
        Invoke-Retry -ScriptBlock {
            Ensure-GroupInSite -GroupName $readSPGroup
        }

        Invoke-Retry -ScriptBlock {
            Ensure-GroupInSite -GroupName $editSPGroup
        }

        # Grant permissions to SharePoint groups
        Invoke-Retry -ScriptBlock {
            Grant-LibraryPermission `
                -LibraryName $libraryName `
                -GroupName $ownersSPGroup `
                -Role "Full Control"
        }

        Invoke-Retry -ScriptBlock {
            Grant-LibraryPermission `
                -LibraryName $libraryName `
                -GroupName $readSPGroup `
                -Role "Read"
        }

        Invoke-Retry -ScriptBlock {
            Grant-LibraryPermission `
                -LibraryName $libraryName `
                -GroupName $editSPGroup `
                -Role "Edit"
        }

        # Add Entra groups as members of SharePoint groups
        Invoke-Retry -ScriptBlock {
            Add-EntraGroupToSPGroup `
                -SPGroupName $readSPGroup `
                -EntraGroupId $readGroupId
        }

        Invoke-Retry -ScriptBlock {
            Add-EntraGroupToSPGroup `
                -SPGroupName $editSPGroup `
                -EntraGroupId $editGroupId
        }

        # EXTERNAL SHARING START
        if ($enableExternalSharing -and $libraryType -eq "external") {
            Write-Log "External sharing requested for $libraryName"

            foreach ($externalUser in $externalUsers) {
                $membershipStatus = Invoke-Retry -ScriptBlock {
                    Add-ExternalUserToSPGroup `
                        -SPGroupName $editSPGroup `
                        -UserEmail $externalUser
                }

                if ($membershipStatus -eq "already_exists") {
                    $externalUsersSkipped += $externalUser
                }
                else {
                    $externalUsersAdded += $externalUser
                }
            }

            if ($externalRole -ne "Edit") {
                Invoke-Retry -ScriptBlock {
                    Grant-LibraryPermission `
                        -LibraryName $libraryName `
                        -GroupName $editSPGroup `
                        -Role $externalRole
                }
            }
        }
        elseif ($libraryType -eq "external") {
            Write-Log "External sharing skipped for $libraryName because ENABLE_LIBRARY_EXTERNAL_SHARING is disabled" "WARN"
        }
        # EXTERNAL SHARING END

        $result += @{
            Library        = $libraryName
            Type           = $libraryType
            OwnersGroup    = $ownersGroup
            ReadGroup      = $readGroup
            EditGroup      = $editGroup
            OwnersSPGroup  = $ownersSPGroup
            ReadSPGroup    = $readSPGroup
            EditSPGroup    = $editSPGroup
            ExternalEnabled = $enableExternalSharing
            ExternalTargetSPGroup = $externalTargetSPGroup
            ExternalUsersRequested = $externalUsers
            ExternalUsersAdded = $externalUsersAdded
            ExternalUsersSkipped = $externalUsersSkipped
            Status         = "Success"
        }

        Write-Log "$libraryName completed"
    }
    catch {
        $failedCount++
        $errorMessage = $_.Exception.Message
        Write-Log "$libraryName failed: $errorMessage" "ERROR"

        $result += @{
            Library       = $libraryName
            Type          = $libraryType
            OwnersGroup   = $ownersGroup
            ReadGroup     = $readGroup
            EditGroup     = $editGroup
            OwnersSPGroup = $ownersSPGroup
            ReadSPGroup   = $readSPGroup
            EditSPGroup   = $editSPGroup
            ExternalEnabled = $enableExternalSharing
            ExternalTargetSPGroup = $externalTargetSPGroup
            ExternalUsersRequested = $externalUsers
            ExternalUsersAdded = $externalUsersAdded
            ExternalUsersSkipped = $externalUsersSkipped
            Status        = "Failed"
            Error         = $errorMessage
        }
    }
}

$overallStatus = if ($failedCount -eq 0) {
    "success"
}
elseif ($failedCount -lt $libraries.Count) {
    "partial_failure"
}
else {
    "failed"
}

$statusCode = if ($overallStatus -eq "success") {
    200
}
elseif ($overallStatus -eq "partial_failure") {
    207
}
else {
    500
}

$response = @{
    status      = $overallStatus
    siteUrl     = $siteUrl
    ownersGroup = $ownersGroup
    results     = $result
}

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = $statusCode
        Body       = ($response | ConvertTo-Json -Depth 10)
    })
}
catch {
    $errorMessage = $_.Exception.Message

    if (Get-Command Write-Log -ErrorAction SilentlyContinue) {
        Write-Log "Unhandled error: $errorMessage" "ERROR"
    }
    else {
        Write-Host "Unhandled error: $errorMessage" -ForegroundColor Red
    }

    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = 500
        Body       = (@{
            status = "failed"
            error  = $errorMessage
        } | ConvertTo-Json)
    })
}