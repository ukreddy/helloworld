param($Request, $TriggerMetadata)

. "$PSScriptRoot/../Shared/helpers.ps1"

Write-Log "Function started"

function Get-RequestBodyObject {
    param($HttpRequest)

    if (-not $HttpRequest.Body) {
        return $null
    }

    if ($HttpRequest.Body -is [string]) {
        if ([string]::IsNullOrWhiteSpace($HttpRequest.Body)) {
            return $null
        }

        try {
            return $HttpRequest.Body | ConvertFrom-Json -ErrorAction Stop
        }
        catch {
            throw "Request body must be valid JSON."
        }
    }

    return $HttpRequest.Body
}

# -----------------------------
# CONFIG
# -----------------------------
$tenant="n8gv"
$adminUrl = "https://$tenant-admin.sharepoint.com"

$tenantId = $env:PNP_TENANT_ID
$clientId = $env:PNP_CLIENT_ID
$certBase64 = $env:PNP_CERT_BASE64
$certPassword = $env:PNP_CERT_PASSWORD

$securePassword = ConvertTo-SecureString $certPassword -AsPlainText -Force

# -----------------------------
# INPUT
# -----------------------------
$bodyObject = Get-RequestBodyObject -HttpRequest $Request

$jobNumber = $Request.Query.jobNumber
if (-not $jobNumber -and $bodyObject) { $jobNumber = $bodyObject.jobNumber }
if (-not $jobNumber) { $jobNumber = "1002" }

$siteUrl = "https://$tenant.sharepoint.com/sites/PC-JOB-$jobNumber"
$siteTitle = "PC-JOB-$jobNumber"

$siteDescription = $Request.Query.siteDescription
if (-not $siteDescription -and $bodyObject) { $siteDescription = $bodyObject.siteDescription }

$customLogoUrl = [string]$env:CUSTOM_LOGO_URL

$owner = "udayadmin@n8gv.onmicrosoft.com"

# -----------------------------
# CONNECT (RETRY)
# -----------------------------
Invoke-Retry -MaxRetries 3 -ScriptBlock {
    Write-Log "Connecting to SharePoint"

    Connect-PnPOnline `
        -Url $adminUrl `
        -Tenant $tenantId `
        -ClientId $clientId `
        -CertificateBase64Encoded $certBase64 `
        -CertificatePassword $securePassword

    Write-Log "Connected successfully"
}

# -----------------------------
# CREATE SITE (RETRY)
# -----------------------------
Invoke-Retry -MaxRetries 3 -ScriptBlock {
    Write-Log "Creating site $siteUrl"

    New-PnPSite `
        -Type TeamSiteWithoutMicrosoft365Group `
        -Title $siteTitle `
        -Url $siteUrl `
        -Owner $owner `
        -Lcid 1033 `
        -Wait

    Write-Log "Site created successfully"
}

if (-not [string]::IsNullOrWhiteSpace([string]$siteDescription) -or
    -not [string]::IsNullOrWhiteSpace([string]$customLogoUrl)) {
    Invoke-Retry -MaxRetries 3 -ScriptBlock {
        Write-Log "Updating site properties"

        Connect-PnPOnline `
            -Url $siteUrl `
            -Tenant $tenantId `
            -ClientId $clientId `
            -CertificateBase64Encoded $certBase64 `
            -CertificatePassword $securePassword

        if (-not [string]::IsNullOrWhiteSpace([string]$siteDescription)) {
            Set-PnPWeb -Description ([string]$siteDescription)
            Write-Log "Site description updated"
        }

        if (-not [string]::IsNullOrWhiteSpace([string]$customLogoUrl)) {
            Set-PnPWeb -SiteLogoUrl ([string]$customLogoUrl)
            Write-Log "Site logo updated from CUSTOM_LOGO_URL"
        }
    }
}

# Provision home page with recent activity and site information
Invoke-Retry -MaxRetries 3 -ScriptBlock {
    Write-Log "Provisioning home page"
    
    Connect-PnPOnline `
        -Url $siteUrl `
        -Tenant $tenantId `
        -ClientId $clientId `
        -CertificateBase64Encoded $certBase64 `
        -CertificatePassword $securePassword

    Provision-HomePage `
        -SiteUrl $siteUrl `
        -JobNumber $jobNumber `
        -CreatedDate (Get-Date)
    
    Write-Log "Home page provisioned successfully"
}

# -----------------------------
# RESPONSE
# -----------------------------
$response = @{
    status = "success"
    siteUrl = $siteUrl
    siteDescription = $siteDescription
    customLogoUrl = $customLogoUrl
}

Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = 200
    Body = ($response | ConvertTo-Json)
})