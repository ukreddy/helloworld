param($Request, $TriggerMetadata)

. "$PSScriptRoot/../Shared/helpers.ps1"

Write-Log "Provision Libraries Started"

$tenant = "n8gv"

$jobNumber = $Request.Query.jobNumber

if (-not $jobNumber) {
    throw "jobNumber is required"
}

$siteUrl = "https://$tenant.sharepoint.com/sites/PC-JOB-$jobNumber"

$libraries = @(
    @{
        Name = "HR Materials"
        ShortName = "HR"
    },
    @{
        Name = "Training"
        ShortName = "TRAIN"
    },
    @{
        Name = "Client Documents"
        ShortName = "CLIENT"
    }
)

# Connect SharePoint
Invoke-Retry -ScriptBlock {
    Connect-SPSite -SiteUrl $siteUrl
}

# Connect Graph
Invoke-Retry -ScriptBlock {
    Connect-GraphApi
}

$result = @()

foreach ($library in $libraries) {

    $libraryName = $library.Name
    $shortName   = $library.ShortName

    Write-Log "Processing $libraryName"

    $readGroup = "PC-JOB-$jobNumber-$shortName-R"
    $editGroup = "PC-JOB-$jobNumber-$shortName-RW"

    # Create Library
    Invoke-Retry -ScriptBlock {
        New-LibraryIfMissing -LibraryName $libraryName
    }

    # Create Entra Groups
    $readGroupId = Invoke-Retry -ScriptBlock {
        New-EntraGroupIfMissing -GroupName $readGroup
    }

    $editGroupId = Invoke-Retry -ScriptBlock {
        New-EntraGroupIfMissing -GroupName $editGroup
    }

    Write-Log "Read Group Id : $readGroupId"
    Write-Log "Edit Group Id : $editGroupId"

    Write-Log "Waiting for Entra groups to propagate..."
    Start-Sleep -Seconds 30

    # Break inheritance
    Invoke-Retry -ScriptBlock {
        Break-LibraryInheritance -LibraryName $libraryName
    }

    # Ensure principals in site
    Invoke-Retry -ScriptBlock {
        Ensure-GroupInSite -GroupName $readGroup
    }

    Invoke-Retry -ScriptBlock {
        Ensure-GroupInSite -GroupName $editGroup
    }

    # Grant permissions (USE IDs, NOT polluted logs)
    Invoke-Retry -ScriptBlock {
        Grant-LibraryPermission `
            -LibraryName $libraryName `
            -GroupName $readGroup `
            -Role "Read"
    }

    Invoke-Retry -ScriptBlock {
        Grant-LibraryPermission `
            -LibraryName $libraryName `
            -GroupName $editGroup `
            -Role "Edit"
    }

    $result += @{
        Library   = $libraryName
        ReadGroup = $readGroup
        EditGroup = $editGroup
        Status    = "Success"
    }

    Write-Log "$libraryName completed"
}

$response = @{
    status  = "success"
    siteUrl = $siteUrl
    results = $result
}

Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = 200
    Body       = ($response | ConvertTo-Json -Depth 10)
})