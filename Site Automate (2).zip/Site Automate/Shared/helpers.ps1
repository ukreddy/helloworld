function Write-Log {
    param($Message, $Level = "INFO")

    $time = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Output "[$time] [$Level] $Message"
}

function Invoke-Retry {
    param(
        [scriptblock]$ScriptBlock,
        [int]$MaxRetries = 3,
        [int]$DelaySeconds = 3
    )

    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            Write-Log "Attempt $i of $MaxRetries"
            return & $ScriptBlock
        }
        catch {
            Write-Log $_.Exception.Message "ERROR"

            if ($i -eq $MaxRetries) { throw }

            Start-Sleep -Seconds ($DelaySeconds * $i)
        }
    }
}

function Connect-SPSite {

    param([string]$SiteUrl)

    Write-Log "Connecting to SharePoint Site"

    $securePassword = ConvertTo-SecureString `
        $env:PNP_CERT_PASSWORD `
        -AsPlainText `
        -Force

    Connect-PnPOnline `
        -Url $SiteUrl `
        -Tenant $env:PNP_TENANT_ID `
        -ClientId $env:PNP_CLIENT_ID `
        -CertificateBase64Encoded $env:PNP_CERT_BASE64 `
        -CertificatePassword $securePassword

    Write-Log "Connected to $SiteUrl"
}

function Connect-GraphApi {

    Write-Log "Connecting Graph API"

    $token = Get-PnPAccessToken

    if (-not $token) {
        throw "Unable to obtain Graph token"
    }

    $script:GraphHeaders = @{
        Authorization  = "Bearer $token"
        "Content-Type" = "application/json"
    }

    Write-Log "Graph ready"
}

function New-LibraryIfMissing {

    param([string]$LibraryName)

    $existing = Get-PnPList -Identity $LibraryName -ErrorAction SilentlyContinue

    if ($existing) {
        Write-Log "Library exists: $LibraryName"
        return
    }

    Write-Log "Creating library: $LibraryName"

    New-PnPList `
        -Title $LibraryName `
        -Template DocumentLibrary `
        -OnQuickLaunch:$true

    Write-Log "Library created: $LibraryName"
}

function New-EntraGroupIfMissing {

    param([string]$GroupName)

    Write-Log "Checking Entra group: $GroupName"

    $filter = [System.Uri]::EscapeDataString("displayName eq '$GroupName'")

    $existing = Invoke-RestMethod `
        -Method GET `
        -Uri "https://graph.microsoft.com/v1.0/groups?`$filter=$filter" `
        -Headers $script:GraphHeaders

    if ($existing.value.Count -gt 0) {
        Write-Log "Group exists"
        return $existing.value[0].id
    }

    Write-Log "Creating Entra group"

    $body = @{
        displayName     = $GroupName
        mailEnabled     = $false
        mailNickname    = ($GroupName -replace '[^a-zA-Z0-9]', '').ToLower()
        securityEnabled = $true
    } | ConvertTo-Json

    $group = Invoke-RestMethod `
        -Method POST `
        -Uri "https://graph.microsoft.com/v1.0/groups" `
        -Headers $script:GraphHeaders `
        -Body $body

    Write-Log "Created group: $($group.id)"

    return $group.id
}

function Break-LibraryInheritance {

    param([string]$LibraryName)

    Write-Log "Breaking inheritance: $LibraryName"

    Set-PnPList `
        -Identity $LibraryName `
        -BreakRoleInheritance `
        -CopyRoleAssignments:$false `
        -ClearSubscopes:$true

    Write-Log "Inheritance broken"
}

# ---------------- FIXED GROUP RESOLUTION ----------------

function Resolve-SPGroup {

    param(
        [string]$GroupName,
        [int]$TimeoutSeconds = 60
    )

    Write-Log "Resolving SP group: $GroupName"

    for ($i = 0; $i -lt $TimeoutSeconds / 5; $i++) {

        $group = Get-PnPGroup -Identity $GroupName -ErrorAction SilentlyContinue

        if ($group) {
            return $group
        }

        Start-Sleep 5
    }

    throw "SharePoint group not found: $GroupName"
}

function Ensure-GroupInSite {

    param([string]$GroupName)

    $existing = Get-PnPGroup -Identity $GroupName -ErrorAction SilentlyContinue

    if ($existing) {
        Write-Log "$GroupName already in site"
        return $existing
    }

    Write-Log "Creating SharePoint group: $GroupName"

    New-PnPGroup -Title $GroupName

    return Resolve-SPGroup -GroupName $GroupName
}

# ---------------- FIXED PERMISSION ----------------

function Grant-LibraryPermission {

    param(
        [string]$LibraryName,
        [string]$GroupName,
        [string]$Role
    )

    Write-Log "Assigning $Role to $GroupName on $LibraryName"

    $group = Resolve-SPGroup -GroupName $GroupName

    Set-PnPListPermission `
        -Identity $LibraryName `
        -Group $group `
        -AddRole $Role

    Write-Log "Permission assigned"
}