param($Request, $TriggerMetadata)

. "$PSScriptRoot/../Shared/helpers.ps1"

Write-Log "Function started"

# -----------------------------
# CONFIG
# -----------------------------
$tenant="n8gv"
$adminUrl = "https://$tenant-admin.sharepoint.com"

$tenantId = $env:PNP_TENANT_ID
$clientId = $env:PNP_CLIENT_ID
$certBase64 = $env:PNP_CERT_BASE64
$certPassword = $env:PNP_CERT_PASSWORD

$securePassword = ConvertTo-SecureString $certPassword -AsPlainText -Force

# -----------------------------
# INPUT
# -----------------------------
$jobNumber = $Request.Query.jobNumber
if (-not $jobNumber) { $jobNumber = "1002" }

$siteUrl = "https://$tenant.sharepoint.com/sites/PC-JOB-$jobNumber"
$siteTitle = "PC-JOB-$jobNumber"

$owner = "udayadmin@n8gv.onmicrosoft.com"

# -----------------------------
# CONNECT (RETRY)
# -----------------------------
Invoke-Retry -MaxRetries 3 -ScriptBlock {
    Write-Log "Connecting to SharePoint"

    Connect-PnPOnline `
        -Url $adminUrl `
        -Tenant $tenantId `
        -ClientId $clientId `
        -CertificateBase64Encoded $certBase64 `
        -CertificatePassword $securePassword

    Write-Log "Connected successfully"
}

# -----------------------------
# CREATE SITE (RETRY)
# -----------------------------
Invoke-Retry -MaxRetries 3 -ScriptBlock {
    Write-Log "Creating site $siteUrl"

    New-PnPSite `
        -Type TeamSiteWithoutMicrosoft365Group `
        -Title $siteTitle `
        -Url $siteUrl `
        -Owner $owner `
        -Lcid 1033 `
        -Wait

    Write-Log "Site created successfully"
}

# -----------------------------
# RESPONSE
# -----------------------------
$response = @{
    status = "success"
    siteUrl = $siteUrl
}

Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = 200
    Body = ($response | ConvertTo-Json)
})